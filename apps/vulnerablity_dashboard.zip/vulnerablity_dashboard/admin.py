from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(vulnerablity_data)
admin.site.register(vulnerablity_analyse_data)
# Register your models here.
