var request_data=""
$("#submit_btn").on("click", function (e) {
    // $('#model_apply_leave').hide()
    //.log("Hidded")
    var shift = $("#Shift_dropdown").val();

    var selected_date = $("#kt_date").val();
    var end_date_start = $("#kt_date").data('daterangepicker');

    var end_date_end = $("#kt_date").data('daterangepicker');
    console.log(end_date_start)
    
    request_data={ "shift": shift, "selected_date": selected_date };
    console.log(request_data,"NEW JS")

    $.ajax({
        method: "GET",
        url: '/shiftpasstool/set_Ticket_count/?created_date=' + selected_date + '',
        success: function (data) {

            get_counts(data)
        }
    })
    $.ajax({
        method: "GET",
        url: '/shiftpasstool/ticket_comment/?created_date=' + selected_date + '',
        success: function (data) {
            get_notes(data)
        }
    })
    
});


function get_counts(data){
    console.log(data,"NEW JSSSS")

    
    get_chartData(data)
    

}

{/* <canvas id="chart_dip" width="112" height="112" data-kt-size="70" data-kt-line="11" style="display: block; box-sizing: border-box; height: 99.5556px; width: 99.5556px;"></canvas> */}


function get_chartData(data){
    if(data != 'No data'){
    console.log(data)
    var total = parseInt(data.alerts)+parseInt(data.manual_incidents)+parseInt(data.problems)+parseInt(data.service_request)
    console.log(total)
    var upd_chart = ''
    var upd_Btn = ''

    upd_chart = upd_chart + 

    ` <div class="row">
    <div class="col-4">
    <div>

    <canvas  id="demoChart"></canvas>
    <span style="position: absolute;
    top: 59%;
    left: 16%;
    font-size: large;
    font-weight: bold;">${total}</span>
   </div>
   </div>

   <div class="col-8">
     <div style="position: relative;left: 20%;top: 10%;">
      <div class="row">
          <div class="col-8">
              <h6 style="color: deepskyblue;"><span style="background-color:#96c8e1;width: 0px;
              height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Alerts</span></h6>
          </div>
       
          <div class="col-3">
              <span style=font-weight:bold;font-size: initial;>${data.alerts}</span>
          </div>

      </div><br>
      <div class="row">
          <div class="col-8">
              <h6 style="color: deepskyblue;"><span style="background-color:#22536d;width: 0px;
              height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Manual Incidents</span></h6>
          </div>
          <div class="col-3">
          <span style=font-weight:bold;font-size: initial;>${data.manual_incidents}</span>
          </div>

      </div><br>
      <div class="row">
      <div class="col-8">
          <h6 style="color: deepskyblue;"><span style="background-color:#fadb5e;width: 0px;
          height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Service Request</span></h6>
      </div>
      <div class="col-3">
          <span style=font-weight:bold;font-size: initial;>${data.service_request}</span>
      </div>

  </div><br>
      <div class="row">
          <div class="col-8">          
              <h6 style="color: deepskyblue;"><span style="background-color:#6f7580;width: 0px;
              height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Problems</span></h6>
          </div>
          <div class="col-3">
              <span style=font-weight:bold;font-size: initial;>${data.problems}</span>
          </div>

      </div>
  
   </div>
   </div>
  </div>`

  $('#floating_chart ').html(upd_chart)

  upd_Btn=upd_Btn+`
    <a href="#" class="btn btn-sm btn-flex btn-primary btn-active-primary fw-bolder" data-bs-toggle="modal"
    data-bs-target="#model_chart_update" id="create_work_group_request_btn" onclick=upate_counts('${data.alerts}','${data.manual_incidents}','${data.problems}','${data.service_request}','${data.date}','${data.shift}')>Update</a>`

    $('#hideUpdate ').html(upd_Btn)

    // chart_dip();

    var ctxD = document.getElementById("demoChart").getContext('2d');
    console.log(ctxD)


    
    var myLineChart = new Chart(ctxD, {
      type: 'doughnut',
      data: {
        // labels: ["Alerts", "Manual Ins", "SRs", "Problem",],
        datasets: [{
          data: [data.alerts, data.manual_incidents, data.service_request, data.problems,],
          backgroundColor: ["#96c8e1", "#22536d", "#fadb5e", "#6f7580",],
          hoverBackgroundColor: ["#96c8e1", "#22536d", "#fadb5e", "#6f7580",]
        }],
      
      },
      options: {
            responsive: true,
        }
    });
    

}
else{
    data={"alerts":"0","manual_incidents":"0","problems":"0","service_request":"0"}

    var upd_chart = ''

    // var upd_Btn = ''

    // upd_chart = upd_chart + `
    // <a href="#" class="btn btn-sm btn-flex btn-primary btn-active-primary fw-bolder" data-bs-toggle="modal"
    //                 data-bs-target="#model_chart" id="create_work_group_request_btn">Create</a>
    // `

    // $('#floating_chart ').html(upd_chart)

    // $('#hideUpdate ').html(upd_Btn)


    var upd_Btn = ''

    upd_chart = upd_chart + 

    ` <div class="row">
    <div class="col-4">
    

    
   </div>
   <div class="col-8">
     <div style="position: relative;left: 20%;top: 10%;">
      <div class="row">
          <div class="col-8">
              <h6 style="color: deepskyblue;"><span style="background-color:#96c8e1;width: 0px;
              height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Alerts</span></h6>
          </div>
       
          <div class="col-3">
              <span style=font-weight:bold;font-size: initial;>${data.alerts}</span>
          </div>

      </div><br>
      <div class="row">
          <div class="col-8">
              <h6 style="color: deepskyblue;"><span style="background-color:#22536d;width: 0px;
              height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Manual Incidents</span></h6>
          </div>
          <div class="col-3">
          <span style=font-weight:bold;font-size: initial;>${data.manual_incidents}</span>
          </div>

      </div><br>
      <div class="row">
      <div class="col-8">
          <h6 style="color: deepskyblue;"><span style="background-color:#fadb5e;width: 0px;
          height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Service Request</span></h6>
      </div>
      <div class="col-3">
          <span style=font-weight:bold;font-size: initial;>${data.service_request}</span>
      </div>

  </div><br>
      <div class="row">
          <div class="col-8">          
              <h6 style="color: deepskyblue;"><span style="background-color:#6f7580;width: 0px;
              height: 10px;" class="badge rounded-circle">&nbsp;</span> &nbsp;&nbsp;<span style="font-size: large;">Problems</span></h6>
          </div>
          <div class="col-3">
              <span style=font-weight:bold;font-size: initial;>${data.problems}</span>
          </div>

      </div>
  
   </div>
   </div>
  </div>`

  $('#floating_chart ').html(upd_chart)

  upd_Btn=upd_Btn+`
    <a href="#" class="btn btn-sm btn-flex btn-primary btn-active-primary fw-bolder" data-bs-toggle="modal"
    data-bs-target="#model_chart_update" id="create_work_group_request_btn" onclick=upate_counts('${data.alerts}','${data.manual_incidents}','${data.problems}','${data.service_request}','${data.date}','${data.shift}')>Update</a>`

    $('#hideUpdate ').html(upd_Btn)

    // chart_dip();

    var ctxD = document.getElementById("demoChart").getContext('2d');
    console.log(ctxD)


    
    var myLineChart = new Chart(ctxD, {
      type: 'doughnut',
      data: {
        // labels: ["Alerts", "Manual Ins", "SRs", "Problem",],
        datasets: [{
          data: [data.alerts, data.manual_incidents, data.service_request, data.problems,],
          backgroundColor: ["#96c8e1", "#22536d", "#fadb5e", "#6f7580",],
          hoverBackgroundColor: ["#96c8e1", "#22536d", "#fadb5e", "#6f7580",]
        }]
      },
     
   
    
    });

}
}

$.ajax({
    method: "GET",
    url: '/shiftpasstool/set_Ticket_count/',
    success: function (data) {

        get_counts(data)
    }
})

function POST_data(){
// $('#submit_button_chart').on('click', function (e) {

    console.log("clicked")
    var dic=JSON.stringify({"alerts":$('#floatingAlerts_update').val(),
    "manual_incidents":$('#floatingManualIncidents_update').val(),
    "problems":$('#floatingProblems_update').val(),
    "service_request":$("#floatingServiceRequest_update").val(),
    "date":request_data['selected_date'],
    "shift":request_data['shift']
})
//     var dic=JSON.stringify({"alerts":$('#floatingAlerts').val(),
//     "manual_incidents":$('#floatingManualIncidents').val(),
//     "problems":$('#floatingProblems').val(),
//     "service_request":$("#floatingServiceRequest").val(),
    
// })

var csrftoken = getCookie('csrftoken');
    var settings = {

        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/set_Ticket_count/",
        "method": "POST",
        "processData": false,
        "data": dic

    }
    $.ajax(settings).done(function (response) {
        console.log(response)
        get_all_count()
        // location.reload()
    })

// })
}


function get_all_count(){
    $.ajax({
        method: "GET",
        url: '/shiftpasstool/set_Ticket_count/',
        success: function (data) {
            get_counts(data)
        }
    })
}

var update_count_ticket={}
function upate_counts(alerts,manual_incidents,problems,service_request,date,shift){

//     console.log("update func clicked")
//     var dic=JSON.stringify({"alerts":$('#floatingAlerts').val(),
//     "manual_incidents":$('#floatingManualIncidents').val(),
//     "problems":$('#floatingProblems').val(),
//     "service_request":$("#floatingServiceRequest").val(),
//     "date":request_data['selected_date'],
//     "shift":request_data['shift']
// })
    document.getElementById('floatingAlerts_update').value=alerts
    document.getElementById('floatingManualIncidents_update').value=manual_incidents
    document.getElementById('floatingProblems_update').value=problems
    document.getElementById('floatingServiceRequest_update').value=service_request
    update_count_ticket['date']=date
    update_count_ticket['shift']=shift


}

$('#submit_button_chart_update').on('click',function (e){

    console.log(update_count_ticket,"update_count_ticket")
    if (update_count_ticket['date'] != "undefined"){
    var dic=JSON.stringify({"alerts":$('#floatingAlerts_update').val(),
    "manual_incidents":$('#floatingManualIncidents_update').val(),
    "problems":$('#floatingProblems_update').val(),
    "service_request":$("#floatingServiceRequest_update").val(),
    "date":update_count_ticket['date'],
    "shift":update_count_ticket['shift']
})
var csrftoken = getCookie('csrftoken');
    var settings = {

        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/set_Ticket_count/",
        "method": "PUT",
        "processData": false,
        "data": dic

    }
    $.ajax(settings).done(function (response) {
        console.log(response)
        get_all_count()
        // location.reload()
    })
}else{
    POST_data()
}




})

// Comment notes

// notes

$('#submit_cmd_btn_notes').on('click',function(e){
    

})

function get_notes(data){

//   document.getElementById('comment_id').value=data.notes
  var upd_notes = ''
  console.log(data,"DATAAAAAAAAAAAAAAAAAAAAAAAAA")
    console.log(Object.keys(data))
  var  upd_button=''
  if (Object.keys(data).length > 0){

    console.log(typeof data.notes)
    
    upd_button=upd_button+      `
  

    
    <a href="#" class="btn btn-sm btn-flex btn-primary btn-active-primary fw-bolder" onclick=update_notes_CMD('${data.date}','${data.shift}') >Update</a>
    `
  upd_notes=upd_notes+`
  

    <textarea class="form-control" rows="5" cols="40" id="comment_id"
     style="font-size: initial;background: aliceblue;width:85%;margin:auto">${data.notes}</textarea><br><br><br>
    
  `
  $('#update_notes').html(upd_notes)
  $('#Update_button_comment').html(upd_button)
  }else{
    data={"notes":"","date":"","shift":""}
    upd_button=upd_button+      `
  
    <a class="btn btn-sm btn-flex btn-primary btn-active-primary fw-bolder" style="margin-left: 5%" onclick=update_notes_CMD('${data.date}','${data.shift}') >Update</a>
    `
    upd_notes=upd_notes+`

    <textarea class="form-control" rows="5" cols="40" id="comment_id"
     style="font-size: initial;background: aliceblue;width:85%;margin:auto">${data.notes}</textarea><br><br><br>
  `
  $('#update_notes').html(upd_notes)
  $('#Update_button_comment').html(upd_button)


  }
//   Update_button_comment


}

$.ajax({
    method: "GET",
    url: '/shiftpasstool/ticket_comment/',
    success: function (data) {
        get_notes(data)
    }
})

function update_notes_CMD(date,shift){
    console.log(date,"date")
    console.log($('#comment_id').val())
    // if (date != ""){
    console.log(request_data)
    if (request_data == ""){
    var dic=JSON.stringify({
        "date":date,
        "shift":shift,
        "notes":$('#comment_id').val()

    })
}else{


    console.log(dic,"DICTTTTT")

    console.log("NOTES")
    // "date":request_data['selected_date'],
    // "shift":request_data['shift']
    // notes:
    var dic=JSON.stringify({
        "date":request_data['selected_date'],
        "shift":request_data['shift'],
        "notes":$('#comment_id').val()

    })
}

    var csrftoken = getCookie('csrftoken');
    var settings = {

        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/ticket_comment/",
        "method": "POST",
        "processData": false,
        "data": dic

    }
    $.ajax(settings).done(function (response) {
        console.log(response)
        // get_notes()
        // location.reload()
    })
// }else{

    
// }

}



// var chart_dip = function() {

//     var endpoint = '/cld/cht/dip'
//     var label = [];
//     var value = [];
//     var label_color = [];
//     var total = 0;
//     var text_with_color = "";
//     var text_sub = "";
//     var text_color = "";
    
//     $.ajax({
//         method: "GET",
//         url: endpoint,
//         success: function(data){
//             label = data.label
//             value = data.value
//             label_color = data.label_color
//             total = data.total
//             text_with_color = data.text_with_color
//             text_sub = data.text_sub
//             text_color = data.text_color
//             init_dip_chart()
//         },
//         error: function(error_data){
//             console.log(JSON.parse(error_data.responseText))
//         }
//     });

//     function init_dip_chart(){
//         if (label !== undefined){

//             url_list = [];

//             label.forEach(function(item, index){

//                 url_list.push("/cld/system?LifeCycleStatus=DIP&SystemRole="+item)

//             })

//             widget_dip = widget_1("chart_dip", "50", text_with_color, text_color, text_sub, total, label, value, label_color, "order-2", url_list)

//             $('#chart_widget_1').append(widget_dip[0]);

//             var ctx = document.getElementById('chart_dip').getContext('2d');

//             ctx.width = 10;
//             ctx.height = 10;      

//             var myDoughnut = new Chart(ctx, widget_dip[1]);
//         }
//     }
// }

/* <canvas id="chart_dip" width="112" height="112" data-kt-size="70" data-kt-line="11" style="display: block; box-sizing: border-box; height: 99.5556px; width: 99.5556px;"></canvas> */




