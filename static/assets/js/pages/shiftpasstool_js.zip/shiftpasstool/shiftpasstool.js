$("#kt_date").flatpickr({
    enableTime: true,
    dateFormat: "Y-m-dTH:i",
});

function convert_date(data) {
    console.log(typeof(data))

    if (data != null){

    var getdate = new Date(data).toUTCString();

    var DateName = getdate.replace("GMT","UTC");

    // var GetMonthNumber = {"Jan":"01", "Feb":"02", "Mar":"03", "Apr":"04", "May":"05", "Jun":"06", "Jul":"07", "Aug":"08", "Sep":"09", "Oct":"10", "Nov":"11", "Dec":"12"}

    // var GetDateSplit = getdate.split(" ");

    // var getdate = GetDateSplit[3]+GetMonthNumber[GetDateSplit[2]]+GetDateSplit[1]+GetDateSplit[4].replace(/\:/g,"");
    // var getdate=getdate
    var output = DateName

    return output;
    }
    else{
        return null
    }
};
// var request_data = [];
// var queryselector=document.querySelector("#kt_date")
// ////.log(queryselector,"queryselector")

$("#submit_btn").on("click", function (e) {
    // $('#model_apply_leave').hide()
    //.log("Hidded")
    var shift = $("#Shift_dropdown").val();

    var selected_date = $("#kt_date").val();
    var end_date_start = $("#kt_date").data('daterangepicker');

    var end_date_end = $("#kt_date").data('daterangepicker');
    console.log(end_date_start)
    // selected_date=convert_date(selected_date)
    // end_date_start = end_date_start.format('YYYY-MM-DD.HH:mm');

    // end_date_end = end_date_end.format('YYYY-MM-DD.HH:mm');
    // console.log(end_date_end)
    //.log(shift, selected_date);
    // var leave_type = $("#leave_dropdown").val();
    request_data={ "shift": shift, "selected_date": selected_date };
    console.log(request_data)
    $.ajax({
        method: "GET",
        url: '/shiftpasstool/outage_get_api/?shift=' + shift + '&created_date=' + selected_date + '',
        success: function (data) {

            generate_change_request_list_dom(data)
        }

    });

    /// SPC TICKET
    $.ajax({
        method: "GET",
        url: '/shiftpasstool/post_tracking/?shift=' + shift + '&created_date=' + selected_date + '',
        success: function (data) {
            generate_change_request_list_SPC(data)

        }

    });
});
// startTimepicker = form.querySelector('#kt_calendar_datepicker_start_time');
// endTimepicker = form.querySelector('#kt_calendar_datepicker_end_time');

// POST outage
$("#submit_button").on('click', function (e) {
    //.log("clicked")

    //.log(request_data[0]['shift'])




    var floatingShift = request_data['shift']
    var floatingdate = request_data['selected_date']
    var floatingTicket = $("#floatingTicket").val();
    var floatingCause = $("#floatingCause").val()
    var floatingCustomerImp = $("#floatingCustomerImp").val();
    var floatingActionReq = $("#floatingActionReq").val();
    // var floatingAction = $("#floatingAction").val();
    var floatingStatus = $("#floatingStatus").val();
    var date = request_data['selected_date']
    // var floatingdate = $("#floatingdate").val();
    // var floatingdate = $("#floatingdate").val();
    data = JSON.stringify({
        "Ticket_ID": floatingTicket,
        "Subject": floatingCause,
        "customer_impact": floatingCustomerImp,
        "Action_Required": floatingActionReq,
        "created_date": floatingdate,
        "shift": floatingShift,
        "Status": floatingStatus,
        "start_time": date
    })



    var csrftoken = getCookie('csrftoken');
    var settings = {

        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/post_api/",
        "method": "POST",
        "processData": false,

        "data": data

    }
    $.ajax(settings).done(function (response) {
        //.log(response)
        // location.reload()
        console.log('res')
        getoutageData()
    })
    // $.ajax({
    //     method: "GET",
    //     url: '/shiftpasstool/outage_get_api/',
    //     success: function (data) {
    //         generate_change_request_list_dom(data)

    //     }

    // });

})




$.ajax({
    method: "GET",
    url: '/shiftpasstool/outage_get_api/',
    success: function (data) {
        generate_change_request_list_dom(data)

    }

});


function getoutageData(){
    console.log("outwork")
    $.ajax({
        method: "GET",
        url: '/shiftpasstool/outage_get_api/',
        success: function (data) {
            console.log("outwork")
            generate_change_request_list_dom(data)

        }

    });
}




function generate_change_request_list_dom(data) {
    var team_options = "";
    var color='';
    var statusHide='';
    // if (data.length==0){
    //     data=[]
    //     data.push({"Ticket_ID": '', "Subject": '', "customer_impact": '', "Action_Required": ''})
    //     //.log("if condition")
    // }
    console.log(data, "outage data")
    if (data['report']){
    if (data['report'].length != 0) {
        data['report'].forEach(function (item) {

            var timeZone= data['timezones'].filter(e=>e.Ticket_ID == item.Ticket_ID)
            timeZone=JSON.stringify(timeZone)

            if(item.Status == 'Resolved'){  
                color= `<span class='badge badge-light-success fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide = ''
            }
            else if(item.Status == 'Waiting'){  
                color= `<span class='badge badge-light-danger fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide=`  <a href=""   onClick='update("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.customer_impact}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}")'  data-bs-toggle="modal" data-bs-target="#updateToken" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black" />
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black" />
                    </svg>
                </span>
                
            </a>`
            }
           else  if(item.Status == 'InProgress'){  
                color= `<span class='badge badge-light-warning fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide=`  <a href=""   onClick='update("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.customer_impact}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}")'  data-bs-toggle="modal" data-bs-target="#updateToken" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black" />
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black" />
                    </svg>
                </span>
                
            </a>`
            }
            else  if(item.Status == 'New'){  
                color= `<span class='badge badge-light-primary fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide=`  <a href=""   onClick='update("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.customer_impact}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}")'  data-bs-toggle="modal" data-bs-target="#updateToken" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black" />
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black" />
                    </svg>
                </span>
                
            </a>`
            }

            team_options = team_options + `<tr>
            
                <td style="text-align:center;font-size: medium;" id=`+ item.ID + `>
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.Ticket_ID + `</label>
                    </div>
                </td>
                <td style="text-align:center;font-size: medium;">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.Subject + `</label>
                    </div>
                </td>
                <td style="text-align:center;font-size: medium;">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.customer_impact + `</label>
                    </div>
                </td>
                <td style="text-align:center;font-size: medium;">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.Action_Required + `</label>
                    </div>
                </td>
                <td style="text-align:center;font-size: medium;">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        `+ color + `

                    </div>
                </td>

                <td style="text-align: center;">
                   ${statusHide}

               <a href=""   onClick='view_outage("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.Action_Taken}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}",${timeZone})'  data-bs-toggle="modal" data-bs-target="#viewToken_outages" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                    <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                    <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                    <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                    <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                  </svg>
                    </span>
                    
                </a>
                    
                </td>
                
            </tr>
            
            `
        })
    } else {

        team_options = team_options + `
            <h3 style="text-align:center">No data found</h3>
        `

    }}else{
        team_options = team_options + `
            <h3 style="text-align:center">No data found</h3>
        `
    }

    $('#swap_request_from_tbody_outages').html(team_options)
}




function update(ID, Ticket_ID, Subject, customer_impact, Action_Required, Status, created_date, shift) {

    // //.log(customer_impact)
    var upd = ''

    // //.log(item,"infunction")
    upd = upd + `
                 <div class="row mt-3" >
                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateTicket" placeholder="Ticket Id" value="`+ Ticket_ID + `">
                            <label for="floatingTicket">Ticket Id</label>
                        </div>

                    </div>
                    </div><br>

                    <div class="row">
                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateCause" placeholder="Cause" value="`+ Subject + `">
                            <label for="floatingCause">Cause</label>
                        </div>
                    </div>
                </div><br>

                <div class="row">
                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateCustomerImp"
                                placeholder="Customer Impact" value="`+ customer_impact + `">
                            <label for="floatingCustomerImp">Customer Impact</label>
                        </div>

                    </div>
                </div><br>

                <div class="row>
            
                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateActionReq"
                                placeholder="Action Required" value="`+ Action_Required + `">
                            <label for="floatingActionReq">Action Required</label>
                        </div>
                    </div>
                </div><br>

                <div class="row">
                    <div class="col">
                        <div class="form-floating">
                        <label for="floatingStatus" >Status</label>
                            <select  class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" id="updateStatus">
                            <option value="InProgress">InProgress</option>
                            <option value="Waiting">Waiting</option>
                            <option value="Resolved">Resolved</option>
                              </select>
                        </div>

                    </div>

                </div><br>

                <button type="submit" id="close_button" class="btn btn-sm btn-light" data-kt-menu-dismiss="true"
                        data-bs-dismiss="modal">Close</button>

                
                <button type="submit" id='update_button' onclick="update_ticket('${created_date}','${shift}')" class="btn btn-sm btn-primary"
                    data-kt-menu-dismiss="true"  data-bs-dismiss="modal">Submit</button>
                
                    
    </div>
                    `
    $('#floatingTickets').html(upd)

}

// $("#modal .close").click()
function update_ticket(created_date, shift) {
    // $('#updateToken').hide()
    $('#modal').modal('toggle');
    //.log("status")
    // $('#updateToken').modal('hide');

    var Ticket_ID = $('#updateTicket').val()

    var Subject = $('#updateCause').val()

    var customer_impact = $('#updateCustomerImp').val()
    var Action_Required = $('#updateActionReq').val()
    var status = $('#updateStatus').val()
    // var updateStatus=status
    var data = JSON.stringify({
        Ticket_ID: Ticket_ID,
        Subject: Subject,
        customer_impact: customer_impact,
        Action_Required: Action_Required,
        Status: status,
        created_date: created_date,
        shift: shift
    })
    //.log(data)

    var csrftoken = getCookie('csrftoken');
    var settings = {
        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/post_api/",
        "method": "PUT",
        "processData": false,

        "data": data

    }
    $.ajax(settings).done(function (response) {
        //.log(response)
        // location.reload()
        getoutageData()
    })
    // $.ajax({
    //     method: "GET",
    //     url: '/shiftpasstool/outage_get_api/',
    //     success: function (data) {
    //         generate_change_request_list_dom(data)

    //     }

    // });

}

$('#update_button').on("click", function (e) {
    //.log("CLICKED", e)

    var updateTicket = $('#updateTicket').val()

    var updateCause = $('#updateCause').val()

    var updateCustomerImp = $('#updateCustomerImp').val()
    var updateActionReq = $('#updateActionReq').val()
    var updateStatus = $('#updateStatus').val()

    var data = JSON.stringify({
        Status: updateStatus
    })
    //.log(data)


    var settings = {
        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/post_api/",
        "method": "PUT",
        "processData": false,

        "data": data

    }
    $ajax(settings).done(function (response) {
        console.log("response")
        getspcData()
    })
    // $.ajax({
    //     method: "GET",
    //     url: '/shiftpasstool/get_tracking/',
    //     success: function (data) {
    //         generate_change_request_list_SPC(data)

    //     }

    // });

});


/// SPC TICKET





$.ajax({
    method: "GET",
    url: '/shiftpasstool/post_tracking/',
    success: function (data) {
        generate_change_request_list_SPC(data)

    }

});

function generate_change_request_list_SPC(data) {
    var team_options1 = "";
    var resData = data;
    var color = '';
    var statusHide = ''
    console.log(data, "resData")
    if (data['new_data1']){
    if (data['new_data1'].length != 0) {
        data['new_data1'].forEach(function (item) {
        // for (let item = 0; item <= data['new_data1'].length; item++) {
            // item = data['new_data1'][item]
            // const start_date = item.start_time

            // const new_start_date = new Date(start_date).toLocaleString('en-GB', {
            //     day: 'numeric',
            //     month: 'long',
            //     year: '2-digit',

            // }).split(' ').join('-');
            // const new_time = `${new Date(start_date).getHours()}:${new Date(start_date).getMinutes()}`
            // const new_Date_Time = `${new_start_date},${new_time}`

            // const end_date = item.end_time
            // console.log(end_date, "from item")
            // // if (end_date == null){
            // //     end_date=''
            // // }
            // const new_end_date = new Date(end_date).toLocaleString('en-GB', {
            //     day: 'numeric',
            //     month: 'long',
            //     year: '2-digit',

            // }).split(' ').join('-');
            // const new_end_time = `${new Date(end_date).getHours()}:${new Date(end_date).getMinutes()}`
            // const new_end_Date_Time = `${new_end_date},${new_end_time}`

            // // 29-October,22 12:53   to   05-November,22 12:53

            // console.log(new_Date_Time, 'to', new_end_Date_Time)

            var timeZone= data['new_data2'].filter(e=>e.Ticket_ID == item.Ticket_ID)
            timeZone=JSON.stringify(timeZone)
            console.log(timeZone)


            if(item.Status == 'Resolved'){  
                color= `<span class='badge badge-light-success fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide=''
            }
            else if(item.Status == 'Waiting'){  
                color= `<span class='badge badge-light-danger fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide=`    <a href=""   onClick='update_spa("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.Action_Taken}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}")'  data-bs-toggle="modal" data-bs-target="#updateToken_spa" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black" />
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black" />
                    </svg>
                </span>
                
            </a>`
            }
           else  if(item.Status == 'InProgress'){  
                color= `<span class='badge badge-light-warning fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide=`    <a href=""   onClick='update_spa("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.Action_Taken}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}")'  data-bs-toggle="modal" data-bs-target="#updateToken_spa" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black" />
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black" />
                    </svg>
                </span>
                
            </a>`
            }
            else  if(item.Status == 'New'){  
                color= `<span class='badge badge-light-primary fs-8 fw-bolder'>`+ item.Status + `</span> `
                statusHide=`    <a href=""   onClick='update_spa("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.Action_Taken}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}")'  data-bs-toggle="modal" data-bs-target="#updateToken_spa" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                        <path opacity="0.3" d="M21.4 8.35303L19.241 10.511L13.485 4.755L15.643 2.59595C16.0248 2.21423 16.5426 1.99988 17.0825 1.99988C17.6224 1.99988 18.1402 2.21423 18.522 2.59595L21.4 5.474C21.7817 5.85581 21.9962 6.37355 21.9962 6.91345C21.9962 7.45335 21.7817 7.97122 21.4 8.35303ZM3.68699 21.932L9.88699 19.865L4.13099 14.109L2.06399 20.309C1.98815 20.5354 1.97703 20.7787 2.03189 21.0111C2.08674 21.2436 2.2054 21.4561 2.37449 21.6248C2.54359 21.7934 2.75641 21.9115 2.989 21.9658C3.22158 22.0201 3.4647 22.0084 3.69099 21.932H3.68699Z" fill="black" />
                        <path d="M5.574 21.3L3.692 21.928C3.46591 22.0032 3.22334 22.0141 2.99144 21.9594C2.75954 21.9046 2.54744 21.7864 2.3789 21.6179C2.21036 21.4495 2.09202 21.2375 2.03711 21.0056C1.9822 20.7737 1.99289 20.5312 2.06799 20.3051L2.696 18.422L5.574 21.3ZM4.13499 14.105L9.891 19.861L19.245 10.507L13.489 4.75098L4.13499 14.105Z" fill="black" />
                    </svg>
                </span>
                
            </a>`
            }


            team_options1 = team_options1 + `<tr>
                <td style="text-align:center" id=`+ item.ID + `>
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.Ticket_ID + `</label>
                    </div>
                </td>
                <td style="text-align:center">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.Subject + `</label>
                    </div>
                </td>
                <td style="text-align:center">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.Action_Taken + `</label>
                    </div>
                </td>
                <td style="text-align:center">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                        <label style="font-size: large;" class="text-muted fw-bold d-block">`+ item.Action_Required + `</label>
                    </div>
                </td>
                <td style="text-align:center">
                    <div class="form-check form-check-sm form-check-custom form-check-solid" style="display: block;">
                       `+ color + `
                    </div>
                </td>
                

                
                <td style="text-align: center;">

                    ${statusHide}

                    <a href=""   onClick='view_spa("${item.ID}","${item.Ticket_ID}","${item.Subject}","${item.Action_Taken}","${item.Action_Required}","${item.Status}","${item.created_date}","${item.shift}",${timeZone})'  data-bs-toggle="modal" data-bs-target="#viewToken_spa" class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1" >
                    <!--begin::Svg Icon | path: icons/duotune/art/art005.svg-->
                    <span class="svg-icon svg-icon-3">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-eye-fill" viewBox="0 0 16 16">
                    <path d="M10.5 8a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0z"/>
                    <path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8zm8 3.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7z"/>
                  </svg>
                    </span>
                    
                </a>


  
                    
                </td>
                
            </tr>
            
            `
        })
    } else {

        team_options1 = team_options1 + `
            <h3>No data found</h3>
            `

    }}else{
        team_options1 = team_options1 + `
            <h3>No data found</h3>
            `
    }
    $('#swap_request_from_tbody').html(team_options1)

}

$("#submit_button_spc").on('click', function (e) {
    console.log("clicked")
    console.log(request_data)
    console.log(request_data['shift'])

    var floatingShift = request_data['shift']
    var floatingdate = request_data['selected_date']
    var floatingTicket = $("#floatingTicket_spc").val();
    var floatingCause = $("#floatingCause_spc").val()
    var floatingCustomerImp = $("#floatingCustomerImp_spc").val();
    var floatingActionReq = $("#floatingActionReq_spc").val();
    // var floatingAction = $("#floatingAction").val();
    var floatingStatus = $("#floatingStatus_spc").val();
    // "start_time":date
    // var floatingdate = $("#floatingdate").val();
    // var floatingdate = $("#floatingdate").val();
    data = JSON.stringify({
        "Ticket_ID": floatingTicket,
        "Subject": floatingCause,
        "Action_Taken": floatingCustomerImp,
        "Action_Required": floatingActionReq,
        "created_date": floatingdate,
        "shift": floatingShift,
        "Status": floatingStatus,
        "start_time": floatingdate
    })



    var csrftoken = getCookie('csrftoken');
    var settings = {

        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/post_tracking/",
        "method": "POST",
        "processData": false,
        "data": data

    }
    $.ajax(settings).done(function (response) {
        console.log(response)
        getspcData()
        // location.reload()
    })
    
    // $.ajax({
    //     method: "GET",
    //     url: '/shiftpasstool/post_tracking/',
    //     success: function (data) {
    //         generate_change_request_list_SPC(data)
    
    //     }
    
    // });
    

})

function getspcData(){
    $.ajax({
        method: "GET",
        url: '/shiftpasstool/post_tracking/',
        success: function (data) {
            generate_change_request_list_SPC(data)
    
        }
    
    });
}


function view_spa(ID, Ticket_ID, Subject, Action_Taken, Action_Required, Status, created_date, shift,timezones) {

    var color=''
    var porgressBar = ''

    console.log(timezones)

    var endDate = timezones.filter(e=>e.end_date != null)
        if(endDate.length != 0){
        endDate=endDate[0]['end_date']
        }

        if(Status == 'Resolved'){  
            color= `<span class='badge badge-light-success fs-8 fw-bolder'>`+ Status + `</span> `
            porgressBar = `<div class="progress-bar bg-success" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>`
        }
        else if(Status == 'Waiting'){  
            color= `<span class='badge badge-light-danger fs-8 fw-bolder'>`+ Status + `</span> `
            porgressBar = `<div class="progress-bar bg-danger" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>`
        }
       else  if(Status == 'InProgress'){  
            color= `<span class='badge badge-light-warning fs-8 fw-bolder'>`+ Status + `</span> `
            porgressBar = `<div class="progress-bar bg-warning" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">50%</div>`
        }

        else  if(Status == 'New'){  
            color= `<span class='badge badge-light-primary fs-8 fw-bolder'>`+ Status + `</span> `
       
        porgressBar = `<div class="progress-bar bg-primary" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%</div>`
        }

    var view_spaDetails = ''
    view_spaDetails = view_spaDetails + `
    <table id="" class="table align-middle table-row-dashed fs-6 gy-5 chart_scrol">
    <thead>
    <tr class="text-center text-gray-400 fw-bolder fs-6 text-uppercase gs-0 table_header h1-font-size">
        <th class="SystemNumber" style"font-weight: bold;">Ticket Id</th>
        <th class="sid" style='width: 40%'>Progress</th>
        <th class="db_sid" style"font-weight: bold;">Status</th>
        <th class="Date" style"font-weight: bold;">Start Date</th>
        <th class="Date" style"font-weight: bold;">End Date</th>
        
    </tr>
    </thead>
    
    <tbody>

    <tr class="text-center text-gray-400 fw-bolder fs-6 text-uppercase gs-0">
    <td>`+ Ticket_ID + `</td>
    <td>
    <div class="progress" style="height: 20px;">
    `+porgressBar+`
    </div>
    </td>
    <td>`+ color + `</td>
    <td>`+ created_date + ` </td>
    <td>`+ endDate + ` </td>
    </tr>
    
    </tbody>
   
</table>
    `
    $('#viewTickets_spa').html(view_spaDetails)


}

function view_outage(ID, Ticket_ID, Subject, Action_Taken, Action_Required, Status, created_date, shift,timezones) {

    var color=''
    var porgressBar = ''

    console.log(timezones)

    var endDate = timezones.filter(e=>e.end_date != null)
        if(endDate.length != 0){
        endDate=endDate[0]['end_date']
        }

        if(Status == 'Resolved'){  
            color= `<span class='badge badge-light-success fs-8 fw-bolder'>`+ Status + `</span> `
            porgressBar = `<div class="progress-bar bg-success" role="progressbar" style="width: 100%;" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100">100%</div>`
        }
        else if(Status == 'Waiting'){  
            color= `<span class='badge badge-light-danger fs-8 fw-bolder'>`+ Status + `</span> `
            porgressBar = `<div class="progress-bar bg-danger" role="progressbar" style="width: 75%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">75%</div>`
        }
       else  if(Status == 'InProgress'){  
            color= `<span class='badge badge-light-warning fs-8 fw-bolder'>`+ Status + `</span> `
            porgressBar = `<div class="progress-bar bg-warning" role="progressbar" style="width: 50%;" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">50%</div>`
        }

        else  if(Status == 'New'){  
            color= `<span class='badge badge-light-primary fs-8 fw-bolder'>`+ Status + `</span> `
       
        porgressBar = `<div class="progress-bar bg-primary" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">25%</div>`
        }



    var view_outageDetails = ''
    view_outageDetails = view_outageDetails + `
     <table id="" class="table align-middle table-row-dashed fs-6 gy-5 chart_scrol">
     <thead>
     <tr class="text-center text-gray-400 fw-bolder fs-6 text-uppercase gs-0 table_header h1-font-size">
         <th class="SystemNumber">Ticket Id</th>
         <th class="sid" style='width: 40%'>Progress</th>
         <th class="db_sid">Status</th>
         <th class="Date">Start Date</th>
         <th class="Date">End Date</th>
     
         
     </tr>
     </thead>
     
     <tbody>
 
     <tr class="text-center text-gray-400 fw-bolder fs-6 text-uppercase gs-0">
     <td>`+ Ticket_ID + `</td>
     <td>
     <div class="progress" style="height: 20px;">
        `+porgressBar+`
   </div>
     </td>
     <td>`+ color + `</td>
     <td>`+ created_date + ` </td>
     <td>`+ endDate + ` </td>
     </tr>
     
     </tbody>
    
 </table>
     `
    $('#viewTickets_outages').html(view_outageDetails)


}



function update_spa(ID, Ticket_ID, Subject, Action_Taken, Action_Required, Status, created_date, shift) {
    // console.log(data,"dates...................")
    var upd_spa = ''

    upd_spa = upd_spa + `
                <div class="row mt-3">
                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateTicket_spa" placeholder="Ticket Id" value="`+ Ticket_ID + `">
                            <label for="floatingTicket">Ticket Id</label>
                        </div>

                    </div>

                 </div><br>
                 
                 <div class="row">

                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateCause_spa" placeholder="Cause" value="`+ Subject + `">
                            <label for="floatingCause">Cause</label>
                        </div>
                    </div>
                </div><br>

                <div class="row">
                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateCustomerImp_spa"
                                placeholder="Customer Impact" value="`+ Action_Taken + `">
                            <label for="floatingCustomerImp">Customer Impact</label>
                        </div>

                    </div>

                   </div><br>

                   <div class="row">

                    <div class="col">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="updateActionReq_spa"
                                placeholder="Action Required" value="`+ Action_Required + `">
                            <label for="floatingActionReq">Action Required</label>
                        </div>
                    </div>
                </div><br>

                <div class="row">
                    <div class="col">
                        <div class="form-floating">
                            <label for="floatingStatus" >Status</label>
                            <select  class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" id="updateStatus_spa">
                                
                                <option value="InProgress">InProgress</option>
                                <option value="Waiting">Waiting</option>
                                <option value="Resolved">Resolved</option>
                              </select>

                        </div>

                    </div>


                </div><br>

                <button type="submit" id="close_button" class="btn btn-sm btn-light" data-kt-menu-dismiss="true"
                data-bs-dismiss="modal">Close</button>
                
                <button type="submit" id='update_button_spa' onclick="update_ticket_spa('${created_date}','${shift}')" class="btn btn-sm btn-primary"
                   data-bs-dismiss="modal">Submit</button>
                
    </div>
                    `
    $('#floatingTickets_spa ').html(upd_spa)

}

function update_ticket_spa(created_date, shift) {

    var Ticket_ID = $('#updateTicket_spa').val()

    var Subject = $('#updateCause_spa').val()

    var customer_impact = $('#updateCustomerImp_spa').val()
    var Action_Required = $('#updateActionReq_spa').val()
    var status = $('#updateStatus_spa').val()
    // var updateStatus=status
    var data = JSON.stringify({
        Ticket_ID: Ticket_ID,
        Subject: Subject,
        Action_Taken: customer_impact,
        Action_Required: Action_Required,
        Status: status,
        created_date: created_date,
        shift: shift
    })

    console.log("update spa", data)

    var csrftoken = getCookie('csrftoken');
    var settings = {
        "headers": { "X-CSRFToken": csrftoken, "Content-Type": "application/json", },
        "async": true,
        "crossDomain": false,
        "url": "/shiftpasstool/update_tracking/",
        "method": "PUT",
        "processData": false,
        "data": data

    }
    $.ajax(settings).done(function (response) {
        console.log(response)
        getspcData()
    })
    // $.ajax({
    //     method: "GET",
    //     url: '/shiftpasstool/post_tracking/',
    //     success: function (data) {
    //         generate_change_request_list_SPC(data)

    //     }

    // });

}








